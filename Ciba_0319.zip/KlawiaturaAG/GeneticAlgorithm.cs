﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KlawiaturaAG
{
    
    internal class GeneticAlgorithm
    {
        public static double FitnessFn(Chromosom input)
        {
            double sum = 0;
            double[,] koszt = new double[,]{ {4, 2, 2, 3, 4, 5, 3, 2, 2, 4 },
                                         { 1.5, 1, 1, 1, 3, 3, 1, 1, 1, 1.5 },
                                         { 4, 4, 3, 2, 5, 3, 2, 3, 4, 4 } };
            Dictionary<char, double> charFreq = new Dictionary<char, double>() {
                {'e', 12.702}, {'t', 9.056}, {'a', 8.167}, {'o', 7.507}, {'i', 6.699}
            };

            for (int i = 0; i < koszt.GetLength(0); i++) { 
                for(int k = 0; k < koszt.GetLength(1); k++)
                {
                    sum += koszt[i, k];
                }
            }

            return sum;
        }

    }
}
